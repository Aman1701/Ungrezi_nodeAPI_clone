const express = require("express");
const router = express.Router();
const multer = require('multer');

const { Learner } = require("../../models/users/learner");

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './public/uploads/profile');
    },
    filename: function (req, file, cb) {
        cb(null, file.originalname)
    }
})

const fileFilter = (req, file, cb) => {
    if (file.mimetype === 'image/jpeg' || file.mimetype === 'image/png') {
        cb(null, true);
    } else {
        cb(null, false);
    }
}

const upload = multer({
    storage: storage,
    limits: {
        fileSize: 1024 * 1024 * 5
    },
    fileFilter: fileFilter
});


router.put('/editProfile/:id', upload.single('profileimg'), (req, res) => {

    const id = req.params.id;
    const { email, name, dob } = req.body;
    let profileimg;
    Learner.findOne({ _id: id }, function (err, user) {
        if (err) {
            res.json({ error: true, message: `Error while finding the user with this ID`, errMessage: err })
        } else if (user) { //if user exists

            if (req.body.email) {
                user.email = email;
            }
            if (req.body.name) {
                user.name = name;
            }
            if (req.body.dob) {
                user.dob = new Date(dob);
            }
            if (req.file) {
                user.image = req.file;
            }
            user.save(function (err, result) {
                if (err) {
                    res.json({
                        error: true,
                        message: err
                    })
                } else if (result) {
                    res.json({
                        error: false,
                        status: "Profile Details updated successfully",
                        message: result
                    })
                    console.log(result);
                } else {
                    res.json({
                        error: true,
                        message: 'Error updating user details'
                    })
                }
            })
        }
        else {//if no such user exists
            res.json({ error: true, message: `No such user with the given id exists` });
        }
    })
})

module.exports = router