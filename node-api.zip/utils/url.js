//const frontUrl = "http://localhost:3000/login";
const frontUrl ="http://www.ungrezi.com/login";
module.exports = frontUrl;
